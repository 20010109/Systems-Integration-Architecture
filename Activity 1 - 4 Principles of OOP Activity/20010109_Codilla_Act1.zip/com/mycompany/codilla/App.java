/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.codilla;

import Abstract.ICar;
import Abstract.VOOMint;
import Abstract.ZXint;
import Concrete.MyCar;
import motorcycles.VOOM;
import motorcycles.ZX4rr;

/**
 *
 * @author User
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Start of program\n\n");
        
//        System.out.println("MyCar");
//        MyCar testCar = new MyCar();
//        testCar.Start();
//        testCar.Stop();
//        testCar.Turbo();
//        
//        System.out.println("AbstractCar");
//        ICar AbstractCar = new MyCar();
//        AbstractCar.Start();
//        AbstractCar.Start();
//        AbstractCar.Stop();

        //Concrete
//        ZX4rr dusky = new ZX4rr();
//        dusky.displayStats("Dusky Saballa");
//        dusky.Start();
//        
//        //Concrete
//        VOOM jl = new VOOM();
//        jl.displayStats("JL Codilla");
//        jl.Start();
        
        //Abstract
        ZXint duskyabstract = new ZX4rr();
        duskyabstract.displayStats("duskyabstract");
        
        //Abstract
        VOOMint jlabstract = new VOOM();
        jlabstract.displayStats("duskyabstract");
        

        
    }
}
