/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorcycles;

import Abstract.VOOMint;

/**
 *
 * @author User
 */
public class VOOM implements VOOMint {
    
    public String brand = "CFMOTO";
    public int mileage = 0;
    public int horsepower = 77;
    public int displacement = 499;
    public String StartOption = "Electric";
    public String FrontBrake = "Disc";
    public String GroundClearance = "140mm";
    public String Transmission = "Manual";
    
    public void Start(){
        System.out.println("STITITITITITIITITIT BRRRRRRRRRRRRRRRRRRRRRR!!!");
    }
    
    public void Stop(){
        System.out.println("whoosh");
    }
    
    public void tractionControlOn(){
        System.out.println("Traction Control On!");
    }
    
    public void tractionControlOff(){
        System.out.println("Traction Control On!");
    }
    
    public void displayStats(String owner){
        System.out.println
        (
                "\nBRAND = " + brand +
                "\nOwner = " + owner +
                "\nMileage = " + mileage +
                "\nHorsepower = " + horsepower +
                "\nDisplacement = " + displacement +
                "\nStart Option = " + StartOption +
                "\nFront Brake = " + FrontBrake + 
                "\nGround Clearance = " + GroundClearance + 
                "\nTransmission = " + Transmission +
                "\nHas Traction Control" 
        );
    }
    
    
    
    
}
