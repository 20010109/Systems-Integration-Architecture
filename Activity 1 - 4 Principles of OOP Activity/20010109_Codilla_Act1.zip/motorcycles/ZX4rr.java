/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorcycles;

import Abstract.ZXint;

/**
 *
 * @author User
 */
public class ZX4rr implements ZXint{
    
    public String brand = "KAWASAKI";
    public int mileage = 0;
    public int horsepower = 76;
    public int displacement = 401;
    public String StartOption = "Electric";
    public String FrontBrake = "Disc";
    public String GroundClearance = "135mm";
    public String Transmission = "Manual";
    
    public void Start(){
        System.out.println("STITITITITITIITITIT BRRRRRRRRRRRRRRRRRRRRRR!!!");
    }
    
    public void Stop(){
        System.out.println("whoosh");
    }
    
    public void displayStats(String owner){
        System.out.println
        (
                "\nBRAND = " + brand +
                "\nOwner = " + owner +
                "\nMileage = " + mileage +
                "\nHorsepower = " + horsepower +
                "\nDisplacement = " + displacement +
                "\nStart Option = " + StartOption +
                "\nFront Brake = " + FrontBrake + 
                "\nGround Clearance = " + GroundClearance + 
                "\nTransmission = " + Transmission +
                "\nDoes not have Traction Control" 
        );
    }
    
    
    
    
}
